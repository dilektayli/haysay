# flask-html-css
A simple website made using Flask, a Python-based microframework, that sends an email to the entered ID.
