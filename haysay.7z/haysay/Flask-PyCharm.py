from gpiozero import MotionSensor, LED
from flask import Flask, render_template
from threading import Thread
import RPi.GPIO as GPIO
import time
import pandas as pd
import joblib

app = Flask(__name__)

pir = MotionSensor(16)
green_led = LED(17)
green_led.off()
my_counter = 0
counter = 0
minute = 1
counter_list = []
make_prediction = False
prediction_labels = []

GPIO.setmode(GPIO.BCM)
gpio_pin = 24
GPIO.setup(gpio_pin, GPIO.IN)

def motion_detection():
    global my_counter, counter_list, make_prediction, prediction_labels

    while True:
        pir.wait_for_motion()
        my_counter += 1
        print("Number of animals: ", my_counter)
        green_led.on()
        pir.wait_for_no_motion()
        green_led.off()
         
        if make_prediction:
        
            prediction_labels = []
            print("prediction starting")
            # Create a DataFrame from the list
            column_names = ["Chews"]  # Replace with your actual feature names
            data = pd.DataFrame(counter_list, columns=column_names)

            # Load the saved model
            loaded_model = joblib.load('haysay_health_model.pkl')

            predictions = loaded_model.predict(data)
            

            # Store the corresponding labels in the prediction_labels list
            labels = ["Healthy" if prediction == 0 else "Unhealthy" for prediction in predictions]
            prediction_labels.extend(labels)
            
            print(predictions)
            print(prediction_labels)

            # Reset variables after making the prediction
            make_prediction = False
        
    
def button_press_callback(gpio_pin):
    global my_counter, counter, counter_list, start_time, minute, make_prediction, prediction_labels
    if GPIO.input(gpio_pin) == GPIO.HIGH and my_counter == 0:
        my_counter += 1
        counter += 1
        print(f"Number of Chews: {counter}")


    elif GPIO.input(gpio_pin) == GPIO.LOW and my_counter > 0:
        my_counter = 0

    elapsed_time = time.time() - start_time
    if elapsed_time >= 20:
        counter_list.append(counter)
        make_prediction = True     
        print(f"At the end of the 20 seconds - Number of chews: {counter_list}")
        start_time = time.time()
        minute += 1
        counter = 0
   

GPIO.add_event_detect(gpio_pin, GPIO.BOTH, callback=button_press_callback, bouncetime=300)

@app.route('/')
def index():
    return render_template('index.html', my_counter=my_counter, counter=counter, counter_list=counter_list, prediction_labels=prediction_labels)

if __name__ == '__main__':
    motion_thread = Thread(target=motion_detection)
    motion_thread.start()
    start_time = time.time()

    try:
        app.run(port=8080)
    except KeyboardInterrupt:
        GPIO.cleanup()
